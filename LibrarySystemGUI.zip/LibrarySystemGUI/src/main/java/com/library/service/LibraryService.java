// com/library/service/LibraryService.java
package com.library.service;

import com.library.model.Book;
import com.library.model.Loan;
import com.library.model.User;

import java.io.*;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Manages all library operations, including books, users, and loans.
 * Handles persistence using Java Serialization.
 */
public class LibraryService {
    // File paths for storing serialized data
    private static final String BOOKS_FILE = "books.ser";
    private static final String USERS_FILE = "users.ser";
    private static final String LOANS_FILE = "loans.ser";

    // Data storage using HashMaps for efficient lookup by ID/ISBN
    private Map<String, Book> booksByIsbn;
    private Map<String, User> usersById;
    private Map<String, Loan> loansById; // Stores all loans, active or returned

    /**
     * Constructs a new LibraryService.
     * Attempts to load existing data from files on startup.
     */
    public LibraryService() {
        booksByIsbn = new HashMap<>();
        usersById = new HashMap<>();
        loansById = new HashMap<>();
        loadData(); // Load data when the service is initialized
    }

    // --- Book Management ---

    /**
     * Adds a new book to the library.
     *
     * @param book The Book object to add.
     * @return True if the book was added successfully (ISBN is unique), false otherwise.
     */
    public boolean addBook(Book book) {
        if (booksByIsbn.containsKey(book.getIsbn())) {
            System.out.println("Error: Book with ISBN " + book.getIsbn() + " already exists.");
            return false;
        }
        booksByIsbn.put(book.getIsbn(), book);
        saveData(); // Save changes
        return true;
    }

    /**
     * Removes a book from the library.
     *
     * @param isbn The ISBN of the book to remove.
     * @return True if the book was removed, false if not found or currently borrowed.
     */
    public boolean removeBook(String isbn) {
        Book book = booksByIsbn.get(isbn);
        if (book == null) {
            System.out.println("Error: Book with ISBN " + isbn + " not found."); // Changed to System.out.println for consistency with GUI messages
            return false;
        }
        if (book.isBorrowed()) {
            System.out.println("Error: Book with ISBN " + isbn + " is currently borrowed and cannot be removed.");
            return false;
        }
        booksByIsbn.remove(isbn);
        saveData();
        return true;
    }

    /**
     * Updates an existing book's details.
     *
     * @param book The Book object with updated details.
     * @return True if the book was updated, false if not found.
     */
    public boolean updateBook(Book book) {
        if (!booksByIsbn.containsKey(book.getIsbn())) {
            System.out.println("Error: Book with ISBN " + book.getIsbn() + " not found for update.");
            return false;
        }
        booksByIsbn.put(book.getIsbn(), book); // Overwrites the existing entry
        saveData();
        return true;
    }

    /**
     * Retrieves a book by its ISBN.
     *
     * @param isbn The ISBN of the book to retrieve.
     * @return The Book object if found, null otherwise.
     */
    public Book getBook(String isbn) {
        return booksByIsbn.get(isbn);
    }

    /**
     * Returns an unmodifiable list of all books in the library.
     *
     * @return A List of all Book objects.
     */
    public List<Book> getAllBooks() {
        return new ArrayList<>(booksByIsbn.values());
    }

    /**
     * Searches for books by title or author (case-insensitive, partial match).
     *
     * @param query The search query string.
     * @return A List of books matching the query.
     */
    public List<Book> searchBooks(String query) {
        String lowerCaseQuery = query.toLowerCase();
        return booksByIsbn.values().stream()
                .filter(book -> book.getTitle().toLowerCase().contains(lowerCaseQuery) ||
                                 book.getAuthor().toLowerCase().contains(lowerCaseQuery))
                .collect(Collectors.toList());
    }

    // --- User Management ---

    /**
     * Registers a new user in the library system.
     *
     * @param user The User object to register.
     * @return True if the user was registered successfully (ID is unique), false otherwise.
     */
    public boolean addUser(User user) {
        if (usersById.containsKey(user.getUserId())) {
            System.out.println("Error: User with ID " + user.getUserId() + " already exists.");
            return false;
        }
        usersById.put(user.getUserId(), user);
        saveData();
        return true;
    }

    /**
     * Removes a user from the library system.
     *
     * @param userId The ID of the user to remove.
     * @return True if the user was removed, false if not found or has active loans.
     */
    public boolean removeUser(String userId) {
        if (!usersById.containsKey(userId)) {
            System.out.println("Error: User with ID " + userId + " not found.");
            return false;
        }
        // Check if user has any active loans
        boolean hasActiveLoans = loansById.values().stream()
                                    .filter(loan -> loan.getUserId().equals(userId) && loan.getReturnDate() == null)
                                    .findAny()
                                    .isPresent();
        if (hasActiveLoans) {
            System.out.println("Error: User " + userId + " has active loans and cannot be removed.");
            return false;
        }
        usersById.remove(userId);
        saveData();
        return true;
    }

    /**
     * Updates an existing user's details.
     *
     * @param user The User object with updated details.
     * @return True if the user was updated, false if not found.
     */
    public boolean updateUser(User user) {
        if (!usersById.containsKey(user.getUserId())) {
            System.out.println("Error: User with ID " + user.getUserId() + " not found for update.");
            return false;
        }
        usersById.put(user.getUserId(), user); // Overwrites the existing entry
        saveData();
        return true;
    }

    /**
     * Retrieves a user by their ID.
     *
     * @param userId The ID of the user to retrieve.
     * @return The User object if found, null otherwise.
     */
    public User getUser(String userId) {
        return usersById.get(userId);
    }

    /**
     * Returns an unmodifiable list of all users in the system.
     *
     * @return A List of all User objects.
     */
    public List<User> getAllUsers() {
        return new ArrayList<>(usersById.values());
    }

    // --- Loan Management ---

    /**
     * Handles the borrowing of a book by a user.
     *
     * @param isbn The ISBN of the book to borrow.
     * @param userId The ID of the user borrowing the book.
     * @return True if the book was successfully borrowed, false otherwise.
     */
    public String borrowBook(String isbn, String userId) {
        Book book = booksByIsbn.get(isbn);
        User user = usersById.get(userId);

        if (book == null) {
            return "Error: Book with ISBN " + isbn + " not found.";
        }
        if (user == null) {
            return "Error: User with ID " + userId + " not found.";
        }
        if (book.isBorrowed()) {
            return "Error: Book '" + book.getTitle() + "' (ISBN: " + isbn + ") is already borrowed.";
        }

        // Set borrow date as today and due date as 14 days from today
        LocalDate borrowDate = LocalDate.now();
        LocalDate dueDate = borrowDate.plusDays(14); // Books are due in 14 days

        Loan loan = new Loan(isbn, userId, borrowDate, dueDate);
        loansById.put(loan.getLoanId(), loan); // Add to general loans map
        book.setBorrowed(true); // Mark the book as borrowed

        saveData();
        return "Book '" + book.getTitle() + "' successfully borrowed by user '" + user.getName() + "'. Due date: " + dueDate;
    }

    /**
     * Handles the return of a borrowed book.
     *
     * @param loanId The ID of the loan to return.
     * @return True if the book was successfully returned, false otherwise.
     */
    public String returnBook(String loanId) {
        Loan loan = loansById.get(loanId);

        if (loan == null) {
            return "Error: Loan with ID " + loanId + " not found.";
        }
        if (loan.getReturnDate() != null) {
            return "Error: Book for Loan ID " + loanId + " has already been returned.";
        }

        Book book = booksByIsbn.get(loan.getBookIsbn());
        if (book == null) {
            // This should ideally not happen if data integrity is maintained
            return "Warning: Associated book for Loan ID " + loanId + " not found. Data inconsistency.";
        }

        loan.setReturnDate(LocalDate.now()); // Set return date to today
        book.setBorrowed(false); // Mark the book as available again

        saveData();
        long overdueDays = loan.getOverdueDays();
        if (overdueDays > 0) {
            return "Book '" + book.getTitle() + "' returned successfully. It was OVERDUE by " + overdueDays + " days.";
            // You could add logic here for calculating and applying fines
        } else {
            return "Book '" + book.getTitle() + "' returned successfully.";
        }
    }

    /**
     * Retrieves all active loans (books currently borrowed).
     *
     * @return A List of active Loan objects.
     */
    public List<Loan> getAllActiveLoans() {
        return loansById.values().stream()
                .filter(loan -> loan.getReturnDate() == null) // Filter for loans without a return date
                .collect(Collectors.toList());
    }

    /**
     * Retrieves all loans (active or returned) associated with a specific user.
     *
     * @param userId The ID of the user.
     * @return A List of Loan objects associated with the user.
     */
    public List<Loan> getLoansByUser(String userId) {
        return loansById.values().stream()
                .filter(loan -> loan.getUserId().equals(userId))
                .collect(Collectors.toList());
    }

    // --- Persistence Methods (Serialization) ---

    /**
     * Saves the current state of books, users, and loans to files using Java Serialization.
     */
    private void saveData() {
        try (ObjectOutputStream oosBooks = new ObjectOutputStream(new FileOutputStream(BOOKS_FILE));
             ObjectOutputStream oosUsers = new ObjectOutputStream(new FileOutputStream(USERS_FILE));
             ObjectOutputStream oosLoans = new ObjectOutputStream(new FileOutputStream(LOANS_FILE))) {

            oosBooks.writeObject(booksByIsbn);
            oosUsers.writeObject(usersById);
            oosLoans.writeObject(loansById);
            // System.out.println("Data saved successfully."); // Uncomment for debugging
        } catch (IOException e) {
            System.err.println("Error saving data: " + e.getMessage());
        }
    }

    /**
     * Loads the state of books, users, and loans from files using Java Deserialization.
     * If files do not exist, new empty maps are initialized.
     */
    private void loadData() {
        try (ObjectInputStream oisBooks = new ObjectInputStream(new FileInputStream(BOOKS_FILE))) {
            booksByIsbn = (Map<String, Book>) oisBooks.readObject();
        } catch (FileNotFoundException e) {
            System.out.println("Books data file not found. Starting with empty book collection.");
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading books data: " + e.getMessage());
        }

        try (ObjectInputStream oisUsers = new ObjectInputStream(new FileInputStream(USERS_FILE))) {
            usersById = (Map<String, User>) oisUsers.readObject();
        } catch (FileNotFoundException e) {
            System.out.println("Users data file not found. Starting with empty user collection.");
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading users data: " + e.getMessage());
        }

        try (ObjectInputStream oisLoans = new ObjectInputStream(new FileInputStream(LOANS_FILE))) {
            loansById = (Map<String, Loan>) oisLoans.readObject();
        } catch (FileNotFoundException e) {
            System.out.println("Loans data file not found. Starting with empty loan collection.");
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading loans data: " + e.getMessage());
        }
        // System.out.println("Data loaded successfully."); // Uncomment for debugging
    }
}
