// com/library/gui/UserPanel.java
package com.library.gui;

import com.library.model.User;
import com.library.service.LibraryService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * JPanel for managing users (add, view, update, delete).
 * Displays users in a JTable.
 */
public class UserPanel extends JPanel {
    private LibraryService libraryService;

    // GUI Components for input
    private JTextField userIdField, nameField, contactInfoField;
    private JButton addButton, updateButton, deleteButton, clearButton;

    // Table to display users
    private JTable userTable;
    private DefaultTableModel tableModel;

    /**
     * Constructs the UserPanel.
     *
     * @param libraryService The LibraryService instance to interact with.
     */
    public UserPanel(LibraryService libraryService) {
        this.libraryService = libraryService;
        setLayout(new BorderLayout(10, 10));

        // Create the input form panel
        JPanel inputFormPanel = createInputFormPanel();
        add(inputFormPanel, BorderLayout.NORTH);

        // Create the table panel
        JPanel tablePanel = createTablePanel();
        add(new JScrollPane(tablePanel), BorderLayout.CENTER);

        // Create the action buttons panel
        JPanel actionButtonPanel = createActionButtonPanel();
        add(actionButtonPanel, BorderLayout.SOUTH);

        refreshUserTable(); // Populate table on initialization
    }

    /**
     * Creates and configures the panel for user input fields.
     *
     * @return The configured JPanel.
     */
    private JPanel createInputFormPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createTitledBorder("User Details"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Row 0: User ID
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("User ID:"), gbc);
        gbc.gridx = 1; gbc.gridwidth = 2;
        userIdField = new JTextField(20);
        panel.add(userIdField, gbc);

        // Row 1: Name
        gbc.gridx = 0; gbc.gridy = 1;
        gbc.gridwidth = 1;
        panel.add(new JLabel("Name:"), gbc);
        gbc.gridx = 1; gbc.gridwidth = 2;
        nameField = new JTextField(20);
        panel.add(nameField, gbc);

        // Row 2: Contact Info
        gbc.gridx = 0; gbc.gridy = 2;
        gbc.gridwidth = 1;
        panel.add(new JLabel("Contact:"), gbc);
        gbc.gridx = 1; gbc.gridwidth = 2;
        contactInfoField = new JTextField(20);
        panel.add(contactInfoField, gbc);

        return panel;
    }

    /**
     * Creates and configures the panel containing the JTable for displaying users.
     *
     * @return The configured JPanel.
     */
    private JPanel createTablePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        String[] columnNames = {"User ID", "Name", "Contact Info"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        userTable = new JTable(tableModel);

        // Add a ListSelectionListener to populate fields when a row is selected
        userTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && userTable.getSelectedRow() != -1) {
                int selectedRow = userTable.getSelectedRow();
                userIdField.setText(tableModel.getValueAt(selectedRow, 0).toString());
                nameField.setText(tableModel.getValueAt(selectedRow, 1).toString());
                contactInfoField.setText(tableModel.getValueAt(selectedRow, 2).toString());
                userIdField.setEditable(false); // Make User ID non-editable for update
            }
        });

        panel.add(new JScrollPane(userTable), BorderLayout.CENTER);
        return panel;
    }

    /**
     * Creates and configures the panel for action buttons (Add, Update, Delete, Clear).
     *
     * @return The configured JPanel.
     */
    private JPanel createActionButtonPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        addButton = new JButton("Add User");
        updateButton = new JButton("Update User");
        deleteButton = new JButton("Delete User");
        clearButton = new JButton("Clear Fields");

        addButton.addActionListener(e -> addUser());
        updateButton.addActionListener(e -> updateUser());
        deleteButton.addActionListener(e -> deleteUser());
        clearButton.addActionListener(e -> clearFields());

        panel.add(addButton);
        panel.add(updateButton);
        panel.add(deleteButton);
        panel.add(clearButton);
        return panel;
    }

    /**
     * Clears all input fields and makes User ID field editable again.
     */
    private void clearFields() {
        userIdField.setText("");
        nameField.setText("");
        contactInfoField.setText("");
        userIdField.setEditable(true);
        refreshUserTable(); // Show all users again
    }

    /**
     * Adds a new user based on input field values.
     */
    private void addUser() {
        String userId = userIdField.getText().trim();
        String name = nameField.getText().trim();
        String contactInfo = contactInfoField.getText().trim();

        if (userId.isEmpty() || name.isEmpty() || contactInfo.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields must be filled for adding a user.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        User newUser = new User(userId, name, contactInfo);
        if (libraryService.addUser(newUser)) {
            JOptionPane.showMessageDialog(this, "User added successfully!");
            clearFields();
            refreshUserTable();
        } else {
            JOptionPane.showMessageDialog(this, "Failed to add user. User ID might already exist.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Updates an existing user based on input field values.
     */
    private void updateUser() {
        String userId = userIdField.getText().trim();
        String name = nameField.getText().trim();
        String contactInfo = contactInfoField.getText().trim();

        if (userId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "User ID is required to update a user. Select a user from the table or enter ID.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        User existingUser = libraryService.getUser(userId);
        if (existingUser == null) {
            JOptionPane.showMessageDialog(this, "User with ID " + userId + " not found.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!name.isEmpty()) existingUser.setName(name);
        if (!contactInfo.isEmpty()) existingUser.setContactInfo(contactInfo);

        if (libraryService.updateUser(existingUser)) {
            JOptionPane.showMessageDialog(this, "User updated successfully!");
            clearFields();
            refreshUserTable();
        } else {
            JOptionPane.showMessageDialog(this, "Failed to update user.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Deletes a user based on the User ID in the input field.
     */
    private void deleteUser() {
        String userId = userIdField.getText().trim();
        if (userId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter the User ID of the user to delete.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete user with ID: " + userId + "?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (libraryService.removeUser(userId)) {
                JOptionPane.showMessageDialog(this, "User deleted successfully!");
                clearFields();
                refreshUserTable();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to delete user. User might have active loans or not found.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    /**
     * Refreshes the user table with all users from the library service.
     */
    public void refreshUserTable() {
        updateUserTable(libraryService.getAllUsers());
    }

    /**
     * Updates the JTable with the provided list of users.
     *
     * @param users The list of users to display.
     */
    private void updateUserTable(List<User> users) {
        tableModel.setRowCount(0); // Clear existing rows
        for (User user : users) {
            tableModel.addRow(new Object[]{
                user.getUserId(),
                user.getName(),
                user.getContactInfo()
            });
        }
    }
}
