// com/library/gui/BookPanel.java
package com.library.gui;

import com.library.model.Book;
import com.library.service.LibraryService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

/**
 * JPanel for managing books (add, view, update, delete, search).
 * Displays books in a JTable.
 */
public class BookPanel extends JPanel {
    private LibraryService libraryService;

    // GUI Components for input
    private JTextField isbnField, titleField, authorField, publisherField, yearField, searchField;
    private JButton addButton, updateButton, deleteButton, searchButton, clearButton;

    // Table to display books
    private JTable bookTable;
    private DefaultTableModel tableModel;

    /**
     * Constructs the BookPanel.
     *
     * @param libraryService The LibraryService instance to interact with.
     */
    public BookPanel(LibraryService libraryService) {
        this.libraryService = libraryService;
        setLayout(new BorderLayout(10, 10)); // Use BorderLayout for overall layout

        // Create the input form panel
        JPanel inputFormPanel = createInputFormPanel();
        add(inputFormPanel, BorderLayout.NORTH); // Place input form at the top

        // Create the table panel
        JPanel tablePanel = createTablePanel();
        add(new JScrollPane(tablePanel), BorderLayout.CENTER); // Place table in the center with scrollability

        // Create the action buttons panel
        JPanel actionButtonPanel = createActionButtonPanel();
        add(actionButtonPanel, BorderLayout.SOUTH); // Place buttons at the bottom

        refreshBookTable(); // Populate table on initialization
    }

    /**
     * Creates and configures the panel for book input fields.
     *
     * @return The configured JPanel.
     */
    private JPanel createInputFormPanel() {
        JPanel panel = new JPanel(new GridBagLayout()); // Use GridBagLayout for flexible form layout
        panel.setBorder(BorderFactory.createTitledBorder("Book Details"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5); // Padding
        gbc.fill = GridBagConstraints.HORIZONTAL; // Stretch components horizontally

        // Row 0: ISBN
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("ISBN:"), gbc);
        gbc.gridx = 1; gbc.gridwidth = 2; // Span 2 columns for text field
        isbnField = new JTextField(20);
        panel.add(isbnField, gbc);

        // Row 1: Title
        gbc.gridx = 0; gbc.gridy = 1;
        gbc.gridwidth = 1; // Reset gridwidth
        panel.add(new JLabel("Title:"), gbc);
        gbc.gridx = 1; gbc.gridwidth = 2;
        titleField = new JTextField(20);
        panel.add(titleField, gbc);

        // Row 2: Author
        gbc.gridx = 0; gbc.gridy = 2;
        gbc.gridwidth = 1;
        panel.add(new JLabel("Author:"), gbc);
        gbc.gridx = 1; gbc.gridwidth = 2;
        authorField = new JTextField(20);
        panel.add(authorField, gbc);

        // Row 3: Publisher
        gbc.gridx = 0; gbc.gridy = 3;
        gbc.gridwidth = 1;
        panel.add(new JLabel("Publisher:"), gbc);
        gbc.gridx = 1; gbc.gridwidth = 2;
        publisherField = new JTextField(20);
        panel.add(publisherField, gbc);

        // Row 4: Publication Year
        gbc.gridx = 0; gbc.gridy = 4;
        gbc.gridwidth = 1;
        panel.add(new JLabel("Pub. Year:"), gbc);
        gbc.gridx = 1; gbc.gridwidth = 2;
        yearField = new JTextField(20);
        panel.add(yearField, gbc);

        // Row 5: Search
        gbc.gridx = 0; gbc.gridy = 5;
        gbc.gridwidth = 1;
        panel.add(new JLabel("Search:"), gbc);
        gbc.gridx = 1;
        searchField = new JTextField(15); // Smaller for search
        panel.add(searchField, gbc);
        gbc.gridx = 2;
        searchButton = new JButton("Search");
        searchButton.addActionListener(e -> searchBooks());
        panel.add(searchButton, gbc);

        return panel;
    }

    /**
     * Creates and configures the panel containing the JTable for displaying books.
     *
     * @return The configured JPanel.
     */
    private JPanel createTablePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        String[] columnNames = {"ISBN", "Title", "Author", "Publisher", "Year", "Status"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Make all cells non-editable
                return false;
            }
        };
        bookTable = new JTable(tableModel);

        // Add a ListSelectionListener to populate fields when a row is selected
        bookTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && bookTable.getSelectedRow() != -1) {
                int selectedRow = bookTable.getSelectedRow();
                isbnField.setText(tableModel.getValueAt(selectedRow, 0).toString());
                titleField.setText(tableModel.getValueAt(selectedRow, 1).toString());
                authorField.setText(tableModel.getValueAt(selectedRow, 2).toString());
                publisherField.setText(tableModel.getValueAt(selectedRow, 3).toString());
                yearField.setText(tableModel.getValueAt(selectedRow, 4).toString());
                // ISBN field should generally not be editable after selection for update
                isbnField.setEditable(false);
            }
        });

        panel.add(new JScrollPane(bookTable), BorderLayout.CENTER);
        return panel;
    }

    /**
     * Creates and configures the panel for action buttons (Add, Update, Delete, Clear).
     *
     * @return The configured JPanel.
     */
    private JPanel createActionButtonPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10)); // Center buttons
        addButton = new JButton("Add Book");
        updateButton = new JButton("Update Book");
        deleteButton = new JButton("Delete Book");
        clearButton = new JButton("Clear Fields");

        // Add ActionListeners to buttons
        addButton.addActionListener(e -> addBook());
        updateButton.addActionListener(e -> updateBook());
        deleteButton.addActionListener(e -> deleteBook());
        clearButton.addActionListener(e -> clearFields());

        panel.add(addButton);
        panel.add(updateButton);
        panel.add(deleteButton);
        panel.add(clearButton);
        return panel;
    }

    /**
     * Clears all input fields and makes ISBN field editable again.
     */
    private void clearFields() {
        isbnField.setText("");
        titleField.setText("");
        authorField.setText("");
        publisherField.setText("");
        yearField.setText("");
        searchField.setText("");
        isbnField.setEditable(true); // Make ISBN editable for new entries
        refreshBookTable(); // Show all books again
    }

    /**
     * Adds a new book based on input field values.
     */
    private void addBook() {
        String isbn = isbnField.getText().trim();
        String title = titleField.getText().trim();
        String author = authorField.getText().trim();
        String publisher = publisherField.getText().trim();
        int publicationYear;

        if (isbn.isEmpty() || title.isEmpty() || author.isEmpty() || publisher.isEmpty() || yearField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields must be filled for adding a book.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            publicationYear = Integer.parseInt(yearField.getText().trim());
            if (publicationYear <= 0) {
                 JOptionPane.showMessageDialog(this, "Publication year must be a positive number.", "Input Error", JOptionPane.ERROR_MESSAGE);
                 return;
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid Publication Year. Please enter a number.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Book newBook = new Book(isbn, title, author, publisher, publicationYear);
        if (libraryService.addBook(newBook)) {
            JOptionPane.showMessageDialog(this, "Book added successfully!");
            clearFields();
            refreshBookTable();
        } else {
            JOptionPane.showMessageDialog(this, "Failed to add book. ISBN might already exist.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Updates an existing book based on input field values.
     */
    private void updateBook() {
        String isbn = isbnField.getText().trim();
        String title = titleField.getText().trim();
        String author = authorField.getText().trim();
        String publisher = publisherField.getText().trim();
        int publicationYear;

        if (isbn.isEmpty()) {
            JOptionPane.showMessageDialog(this, "ISBN is required to update a book. Select a book from the table or enter ISBN.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Book existingBook = libraryService.getBook(isbn);
        if (existingBook == null) {
            JOptionPane.showMessageDialog(this, "Book with ISBN " + isbn + " not found.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Validate and update fields only if new values are provided
        if (!title.isEmpty()) existingBook.setTitle(title);
        if (!author.isEmpty()) existingBook.setAuthor(author);
        if (!publisher.isEmpty()) existingBook.setPublisher(publisher);

        if (!yearField.getText().trim().isEmpty()) {
            try {
                publicationYear = Integer.parseInt(yearField.getText().trim());
                if (publicationYear <= 0) {
                    JOptionPane.showMessageDialog(this, "Publication year must be a positive number.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                existingBook.setPublicationYear(publicationYear);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid Publication Year. Please enter a number.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        if (libraryService.updateBook(existingBook)) {
            JOptionPane.showMessageDialog(this, "Book updated successfully!");
            clearFields();
            refreshBookTable();
        } else {
            JOptionPane.showMessageDialog(this, "Failed to update book.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Deletes a book based on the ISBN in the input field.
     */
    private void deleteBook() {
        String isbn = isbnField.getText().trim();
        if (isbn.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter the ISBN of the book to delete.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete book with ISBN: " + isbn + "?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (libraryService.removeBook(isbn)) {
                JOptionPane.showMessageDialog(this, "Book deleted successfully!");
                clearFields();
                refreshBookTable();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to delete book. It might be borrowed or not found.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    /**
     * Searches for books based on the query in the search field and updates the table.
     */
    private void searchBooks() {
        String query = searchField.getText().trim();
        if (query.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a search query.", "Input Error", JOptionPane.ERROR_MESSAGE);
            refreshBookTable(); // Show all books if search field is empty
            return;
        }

        List<Book> foundBooks = libraryService.searchBooks(query);
        updateBookTable(foundBooks); // Update table with search results
        if (foundBooks.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No books found matching '" + query + "'.", "Search Results", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    /**
     * Refreshes the book table with all books from the library service.
     */
    public void refreshBookTable() {
        updateBookTable(libraryService.getAllBooks());
    }

    /**
     * Updates the JTable with the provided list of books.
     *
     * @param books The list of books to display.
     */
    private void updateBookTable(List<Book> books) {
        tableModel.setRowCount(0); // Clear existing rows
        for (Book book : books) {
            tableModel.addRow(new Object[]{
                book.getIsbn(),
                book.getTitle(),
                book.getAuthor(),
                book.getPublisher(),
                book.getPublicationYear(),
                book.isBorrowed() ? "Borrowed" : "Available"
            });
        }
    }
}
