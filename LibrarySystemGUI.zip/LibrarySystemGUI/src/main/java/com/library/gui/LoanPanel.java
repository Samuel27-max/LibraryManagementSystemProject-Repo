// com/library/gui/LoanPanel.java
package com.library.gui;

import com.library.model.Loan;
import com.library.service.LibraryService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * JPanel for managing loans (borrow, return, view active loans, view user loans).
 * Displays loans in a JTable.
 */
public class LoanPanel extends JPanel {
    private LibraryService libraryService;

    // GUI Components for input
    private JTextField borrowBookIsbnField, borrowUserIdField, returnLoanIdField, viewUserLoansIdField;
    private JButton borrowButton, returnButton, viewAllActiveLoansButton, viewUserLoansButton;

    // Table to display loans
    private JTable loanTable;
    private DefaultTableModel tableModel;

    /**
     * Constructs the LoanPanel.
     *
     * @param libraryService The LibraryService instance to interact with.
     */
    public LoanPanel(LibraryService libraryService) {
        this.libraryService = libraryService;
        setLayout(new BorderLayout(10, 10));

        // Create the input and action panels for borrowing/returning
        JPanel actionInputPanel = createActionInputPanel();
        add(actionInputPanel, BorderLayout.NORTH);

        // Create the table panel
        JPanel tablePanel = createTablePanel();
        add(new JScrollPane(tablePanel), BorderLayout.CENTER);

        // Create the view loans buttons panel
        JPanel viewLoansButtonPanel = createViewLoansButtonPanel();
        add(viewLoansButtonPanel, BorderLayout.SOUTH);

        refreshLoanTable(); // Populate table on initialization (show active loans by default)
    }

    /**
     * Creates and configures the panel for loan action inputs (borrow/return).
     *
     * @return The configured JPanel.
     */
    private JPanel createActionInputPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Loan Operations"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Borrow Book Section
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("Borrow Book (ISBN):"), gbc);
        gbc.gridx = 1;
        borrowBookIsbnField = new JTextField(15);
        panel.add(borrowBookIsbnField, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("Borrower User ID:"), gbc);
        gbc.gridx = 1;
        borrowUserIdField = new JTextField(15);
        panel.add(borrowUserIdField, gbc);

        gbc.gridx = 2; gbc.gridy = 0; gbc.gridheight = 2; // Span two rows
        borrowButton = new JButton("Borrow Book");
        borrowButton.addActionListener(e -> borrowBook());
        panel.add(borrowButton, gbc);
        gbc.gridheight = 1; // Reset gridheight

        // Return Book Section
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(new JLabel("Return Loan (Loan ID):"), gbc);
        gbc.gridx = 1;
        returnLoanIdField = new JTextField(15);
        panel.add(returnLoanIdField, gbc);

        gbc.gridx = 2; gbc.gridy = 2;
        returnButton = new JButton("Return Book");
        returnButton.addActionListener(e -> returnBook());
        panel.add(returnButton, gbc);

        return panel;
    }

    /**
     * Creates and configures the panel containing the JTable for displaying loans.
     *
     * @return The configured JPanel.
     */
    private JPanel createTablePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        String[] columnNames = {"Loan ID", "Book ISBN", "User ID", "Borrow Date", "Due Date", "Return Date", "Status"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        loanTable = new JTable(tableModel);
        panel.add(new JScrollPane(loanTable), BorderLayout.CENTER);
        return panel;
    }

    /**
     * Creates and configures the panel for viewing loan lists (all active, by user).
     *
     * @return The configured JPanel.
     */
    private JPanel createViewLoansButtonPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));

        viewAllActiveLoansButton = new JButton("View All Active Loans");
        viewAllActiveLoansButton.addActionListener(e -> refreshLoanTable()); // Default refresh shows active

        viewUserLoansIdField = new JTextField(10);
        viewUserLoansButton = new JButton("View Loans by User ID");
        viewUserLoansButton.addActionListener(e -> viewLoansByUser());

        panel.add(viewAllActiveLoansButton);
        panel.add(new JLabel("User ID:"));
        panel.add(viewUserLoansIdField);
        panel.add(viewUserLoansButton);

        return panel;
    }

    /**
     * Handles the borrowing of a book.
     */
    private void borrowBook() {
        String isbn = borrowBookIsbnField.getText().trim();
        String userId = borrowUserIdField.getText().trim();

        if (isbn.isEmpty() || userId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Book ISBN and User ID are required to borrow a book.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String result = libraryService.borrowBook(isbn, userId);
        JOptionPane.showMessageDialog(this, result, "Borrow Result", JOptionPane.INFORMATION_MESSAGE);
        borrowBookIsbnField.setText("");
        borrowUserIdField.setText("");
        refreshLoanTable(); // Refresh table to show new active loan
    }

    /**
     * Handles the returning of a book.
     */
    private void returnBook() {
        String loanId = returnLoanIdField.getText().trim();

        if (loanId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Loan ID is required to return a book.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String result = libraryService.returnBook(loanId);
        JOptionPane.showMessageDialog(this, result, "Return Result", JOptionPane.INFORMATION_MESSAGE);
        returnLoanIdField.setText("");
        refreshLoanTable(); // Refresh table to show updated loan status
    }

    /**
     * Displays all active loans. This is the default behavior of refreshLoanTable().
     */
    public void refreshLoanTable() {
        updateLoanTable(libraryService.getAllActiveLoans());
    }

    /**
     * Displays all loans for a specific user.
     */
    private void viewLoansByUser() {
        String userId = viewUserLoansIdField.getText().trim();
        if (userId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a User ID.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (libraryService.getUser(userId) == null) {
            JOptionPane.showMessageDialog(this, "User with ID " + userId + " not found.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        List<Loan> userLoans = libraryService.getLoansByUser(userId);
        updateLoanTable(userLoans);
        if (userLoans.isEmpty()) {
            JOptionPane.showMessageDialog(this, "User " + userId + " has no loan history.", "Loan History", JOptionPane.INFORMATION_MESSAGE);
        }
        viewUserLoansIdField.setText("");
    }

    /**
     * Updates the JTable with the provided list of loans.
     *
     * @param loans The list of loans to display.
     */
    private void updateLoanTable(List<Loan> loans) {
        tableModel.setRowCount(0); // Clear existing rows
        for (Loan loan : loans) {
            tableModel.addRow(new Object[]{
                loan.getLoanId(),
                loan.getBookIsbn(),
                loan.getUserId(),
                loan.getBorrowDate(),
                loan.getDueDate(),
                loan.getReturnDate() != null ? loan.getReturnDate() : "N/A",
                loan.isOverdue() ? "OVERDUE (" + loan.getOverdueDays() + " days)" : (loan.getReturnDate() != null ? "Returned" : "Active")
            });
        }
    }
}