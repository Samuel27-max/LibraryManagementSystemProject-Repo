// com/library/gui/LibraryGUI.java
package com.library.gui;

import com.library.service.LibraryService;

import javax.swing.*;
import java.awt.*;

/**
 * The main JFrame for the Library Management System GUI.
 * It uses a JTabbedPane to organize different functional panels (Books, Users, Loans).
 */
public class LibraryGUI extends JFrame {
    private LibraryService libraryService;
    private JTabbedPane tabbedPane;
    private BookPanel bookPanel;
    private UserPanel userPanel;
    private LoanPanel loanPanel;

    /**
     * Constructs the main GUI window.
     */
    public LibraryGUI() {
        // Initialize the LibraryService (which handles data loading/saving)
        libraryService = new LibraryService();

        setTitle("Library Management System");
        setSize(800, 600); // Set initial window size
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Exit application on close
        setLocationRelativeTo(null); // Center the window on the screen

        // Initialize JTabbedPane to hold different management sections
        tabbedPane = new JTabbedPane();

        // Initialize and add individual panels for each management area
        bookPanel = new BookPanel(libraryService);
        userPanel = new UserPanel(libraryService);
        loanPanel = new LoanPanel(libraryService);

        tabbedPane.addTab("Books", bookPanel);
        tabbedPane.addTab("Users", userPanel);
        tabbedPane.addTab("Loans", loanPanel);

        // Add a listener to update tables when a tab is selected
        tabbedPane.addChangeListener(e -> {
            int selectedIndex = tabbedPane.getSelectedIndex();
            if (selectedIndex == 0) { // Books tab
                bookPanel.refreshBookTable();
            } else if (selectedIndex == 1) { // Users tab
                userPanel.refreshUserTable();
            } else if (selectedIndex == 2) { // Loans tab
                loanPanel.refreshLoanTable();
            }
        });

        // Add the tabbed pane to the frame's content pane
        add(tabbedPane, BorderLayout.CENTER);
    }
}
