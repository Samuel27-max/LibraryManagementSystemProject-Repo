// Main.java
package com.library;

import com.library.gui.LibraryGUI;

import javax.swing.*;

/**
 * The main class to start the Library Management System GUI application.
 */
public class Main {
    public static void main(String[] args) {
        // Run the GUI creation on the Event Dispatch Thread (EDT)
        // This is crucial for Swing applications to ensure thread safety
        SwingUtilities.invokeLater(() -> {
            LibraryGUI gui = new LibraryGUI();
            gui.setVisible(true); // Make the main window visible
        });
    }
}
