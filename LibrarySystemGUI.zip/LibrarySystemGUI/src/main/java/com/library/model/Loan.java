// com/library/model/Loan.java
package com.library.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Objects;
import java.util.UUID; // For generating unique loan IDs

/**
 * Represents a loan transaction in the library system.
 * Links a borrowed book to a user, with dates for borrowing and return.
 * Implements Serializable to allow saving/loading objects to/from files.
 */
public class Loan implements Serializable {
    private static final long serialVersionUID = 1L; // For serialization version control

    private String loanId; // Unique identifier for this loan
    private String bookIsbn; // ISBN of the borrowed book
    private String userId;   // ID of the user who borrowed the book
    private LocalDate borrowDate;
    private LocalDate dueDate;
    private LocalDate returnDate; // Null if the book has not yet been returned

    /**
     * Constructs a new Loan object.
     *
     * @param bookIsbn The ISBN of the book being borrowed.
     * @param userId The ID of the user borrowing the book.
     * @param borrowDate The date the book was borrowed.
     * @param dueDate The date the book is due for return.
     */
    public Loan(String bookIsbn, String userId, LocalDate borrowDate, LocalDate dueDate) {
        this.loanId = UUID.randomUUID().toString(); // Generate a unique ID for each loan
        this.bookIsbn = bookIsbn;
        this.userId = userId;
        this.borrowDate = borrowDate;
        this.dueDate = dueDate;
        this.returnDate = null; // Book not yet returned
    }

    // --- Getters ---
    public String getLoanId() {
        return loanId;
    }

    public String getBookIsbn() {
        return bookIsbn;
    }

    public String getUserId() {
        return userId;
    }

    public LocalDate getBorrowDate() {
        return borrowDate;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public LocalDate getReturnDate() {
        return returnDate;
    }

    /**
     * Sets the return date for the loan.
     *
     * @param returnDate The date the book was returned.
     */
    public void setReturnDate(LocalDate returnDate) {
        this.returnDate = returnDate;
    }

    /**
     * Checks if the loan is currently overdue.
     * A loan is overdue if the current date is after the due date and the book has not been returned.
     *
     * @return True if the loan is overdue, false otherwise.
     */
    public boolean isOverdue() {
        return returnDate == null && LocalDate.now().isAfter(dueDate);
    }

    /**
     * Calculates the number of days the loan is overdue.
     * Returns a positive number if overdue, 0 or negative otherwise.
     *
     * @return The number of overdue days, or 0 if not overdue/already returned.
     */
    public long getOverdueDays() {
        if (isOverdue()) {
            return ChronoUnit.DAYS.between(dueDate, LocalDate.now());
        }
        if (returnDate != null && returnDate.isAfter(dueDate)) {
            return ChronoUnit.DAYS.between(dueDate, returnDate);
        }
        return 0;
    }

    /**
     * Overrides the equals method to compare Loan objects based on their loanId.
     *
     * @param o The object to compare with.
     * @return True if the objects are equal, false otherwise.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Loan loan = (Loan) o;
        return Objects.equals(loanId, loan.loanId);
    }

    /**
     * Overrides the hashCode method, consistent with the equals method.
     *
     * @return The hash code for the Loan object.
     */
    @Override
    public int hashCode() {
        return Objects.hash(loanId);
    }

    /**
     * Provides a string representation of the Loan object for easy printing.
     *
     * @return A formatted string containing loan details.
     */
    @Override
    public String toString() {
        String status = "Active";
        if (returnDate != null) {
            status = "Returned";
        } else if (isOverdue()) {
            status = "OVERDUE by " + getOverdueDays() + " days";
        }

        return "Loan ID: " + loanId +
               ", Book ISBN: " + bookIsbn +
               ", User ID: " + userId +
               ", Borrow Date: " + borrowDate +
               ", Due Date: " + dueDate +
               ", Return Date: " + (returnDate != null ? returnDate : "N/A") +
               ", Status: " + status;
    }
}
