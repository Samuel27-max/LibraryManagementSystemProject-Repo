// com/library/model/User.java
package com.library.model;

import java.io.Serializable;
import java.util.Objects;

/**
 * Represents a User (member) in the library system.
 * Implements Serializable to allow saving/loading objects to/from files.
 */
public class User implements Serializable {
    private static final long serialVersionUID = 1L; // For serialization version control

    private String userId; // Unique identifier for the user
    private String name;
    private String contactInfo; // e.g., email or phone number

    /**
     * Constructs a new User object.
     *
     * @param userId The unique ID of the user.
     * @param name The name of the user.
     * @param contactInfo The contact information of the user.
     */
    public User(String userId, String name, String contactInfo) {
        this.userId = userId;
        this.name = name;
        this.contactInfo = contactInfo;
    }

    // --- Getters ---
    public String getUserId() {
        return userId;
    }

    public String getName() {
        return name;
    }

    public String getContactInfo() {
        return contactInfo;
    }

    // --- Setters ---
    public void setUserId(String userId) {
        this.userId = userId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setContactInfo(String contactInfo) {
        this.contactInfo = contactInfo;
    }

    /**
     * Overrides the equals method to compare User objects based on their userId.
     * This ensures that two users with the same userId are considered equal.
     *
     * @param o The object to compare with.
     * @return True if the objects are equal, false otherwise.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return Objects.equals(userId, user.userId);
    }

    /**
     * Overrides the hashCode method, consistent with the equals method.
     *
     * @return The hash code for the User object.
     */
    @Override
    public int hashCode() {
        return Objects.hash(userId);
    }

    /**
     * Provides a string representation of the User object for easy printing.
     *
     * @return A formatted string containing user details.
     */
    @Override
    public String toString() {
        return "User ID: " + userId +
               ", Name: '" + name + '\'' +
               ", Contact: '" + contactInfo + '\'';
    }
}
