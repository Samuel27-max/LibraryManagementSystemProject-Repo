// com/library/model/Book.java
package com.library.model;

import java.io.Serializable;
import java.util.Objects;

/**
 * Represents a Book in the library system.
 * Implements Serializable to allow saving/loading objects to/from files.
 */
public class Book implements Serializable {
    private static final long serialVersionUID = 1L; // For serialization version control

    private String isbn; // International Standard Book Number (unique identifier)
    private String title;
    private String author;
    private String publisher;
    private int publicationYear;
    private boolean isBorrowed; // True if the book is currently borrowed, false otherwise

    /**
     * Constructs a new Book object.
     *
     * @param isbn The unique ISBN of the book.
     * @param title The title of the book.
     * @param author The author of the book.
     * @param publisher The publisher of the book.
     * @param publicationYear The year the book was published.
     */
    public Book(String isbn, String title, String author, String publisher, int publicationYear) {
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.publisher = publisher;
        this.publicationYear = publicationYear;
        this.isBorrowed = false; // A new book is initially not borrowed
    }

    // --- Getters ---
    public String getIsbn() {
        return isbn;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getPublisher() {
        return publisher;
    }

    public int getPublicationYear() {
        return publicationYear;
    }

    public boolean isBorrowed() {
        return isBorrowed;
    }

    // --- Setters ---
    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public void setPublicationYear(int publicationYear) {
        this.publicationYear = publicationYear;
    }

    public void setBorrowed(boolean borrowed) {
        isBorrowed = borrowed;
    }

    /**
     * Overrides the equals method to compare Book objects based on their ISBN.
     * This ensures that two books with the same ISBN are considered equal.
     *
     * @param o The object to compare with.
     * @return True if the objects are equal, false otherwise.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Book book = (Book) o;
        return Objects.equals(isbn, book.isbn);
    }

    /**
     * Overrides the hashCode method, consistent with the equals method.
     *
     * @return The hash code for the Book object.
     */
    @Override
    public int hashCode() {
        return Objects.hash(isbn);
    }

    /**
     * Provides a string representation of the Book object for easy printing.
     *
     * @return A formatted string containing book details.
     */
    @Override
    public String toString() {
        return "ISBN: " + isbn +
               ", Title: '" + title + '\'' +
               ", Author: '" + author + '\'' +
               ", Year: " + publicationYear +
               ", Status: " + (isBorrowed ? "Borrowed" : "Available");
    }
}
